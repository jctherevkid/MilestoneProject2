#define SCOVEY "The author that you would best learn from is Stephen R Covey"
#define DCARNEGIE "The author that you would best learn from is Dale Carnegie"
#define JWILLINK "The author that you would best learn from is Jocko Willink"
#define AOHANIAN "The author that you would best learn from is Alexis Ohanian"